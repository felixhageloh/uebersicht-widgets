# Dependencies

* python

# Credits

* Icon by AHA-SOFT (http://www.aha-soft.com) 
