# Dependencies

* Python 2.7 
* python-suds (`sudo easy_install -z suds`)

# Configuration

* configure your utc difference in worldcup.py


# Credits

* Icon by AHA-SOFT (http://www.aha-soft.com)
* Original python script by Daniel Noegel (https://github.com/dnoegel/ConkySoccerInterface) 
