Installation:

1. Move calendar.widget to your Ubersicht widgets folder.
2. Enjoy!
