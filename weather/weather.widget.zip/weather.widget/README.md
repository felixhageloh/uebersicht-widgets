# Notes

Replace <api-key> inside `index.coffee` with your own forecast.io api key. You can get yours here: https://developer.forecast.io


# Credits

Icons by Erik Flowers

http://erikflowers.github.io/weather-icons/
