# Notes

Replace <api-key> inside `index.coffee` with your own forecast.io api key. You can get yours here: https://developer.forecast.io. You also need to enter your lat/lon coordinates, which you can find using google maps for example.


# Credits

Icons by Erik Flowers

http://erikflowers.github.io/weather-icons/
