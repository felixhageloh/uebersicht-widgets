# Credits

Authors of the various widgets include:

George Irwin, mfam, Aliceljm, Johan Bleuzen, Spencer Oberstadt, Felix Hageloh
