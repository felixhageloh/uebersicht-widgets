Add these widgets (by various authors) to your Ubersicht widgets folder for a pre-built set of widgets. 

See the screenshot for the result.

Also note that the netstat widget requires minor setup (see README)