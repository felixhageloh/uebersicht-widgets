Ubersicht-Spotify-widget
==========================

Using Ubersicht displays current track palying in spotify on you desktop.

Link to Ubersicht http://tracesof.net/uebersicht/#comment-1445259628

Drop SpotifyCurrentTrack.coffee in you Ubersicht widgets folder and away you go!

You may need to adjust the "top" and "left" position to suite your display


